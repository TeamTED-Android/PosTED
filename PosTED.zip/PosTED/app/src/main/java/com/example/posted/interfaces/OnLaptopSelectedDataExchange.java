package com.example.posted.interfaces;

import com.example.posted.models.LaptopSqlite;

public interface OnLaptopSelectedDataExchange {

    void onLaptopSelected(LaptopSqlite laptop);
}
