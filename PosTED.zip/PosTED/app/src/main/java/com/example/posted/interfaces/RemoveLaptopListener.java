package com.example.posted.interfaces;


public interface RemoveLaptopListener {

    void onRemoved();
}
