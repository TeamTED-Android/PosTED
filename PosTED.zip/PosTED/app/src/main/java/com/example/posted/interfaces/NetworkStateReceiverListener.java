package com.example.posted.interfaces;

public interface NetworkStateReceiverListener {

    void networkAvailable();

    //void networkUnavailable();
}
