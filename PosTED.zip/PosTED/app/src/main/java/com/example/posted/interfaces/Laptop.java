package com.example.posted.interfaces;

public interface Laptop {

    String getModel();

    void setModel(String model);

    String getCapacity_ram();

    void setCapacity_ram(String capacity_ram);

    String getCapacity_hdd();

    void setCapacity_hdd(String capacity_hdd);

    String getProcessor_type();

    void setProcessor_type(String processor_type);

    String getVideo_card_type();

    void setVideo_card_type(String video_card_type);

    String getDisplay_size();

    void setDisplay_size(String display_size);

    String getCurrency();

    void setCurrency(String currency);

    String getPrice();

    void setPrice(String price);

    String getImagePath();

    void setImagePath(String path);

    String getImageName();

    void setImageName(String imgName);
}
